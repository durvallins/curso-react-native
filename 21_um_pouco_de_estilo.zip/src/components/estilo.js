import { StyleSheet } from 'react-native'

export default StyleSheet.create({
    fontG: {
        fontSize: 24
    }
})