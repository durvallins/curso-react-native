import { StyleSheet } from 'react-native'

export default StyleSheet.create({
    txtG: {
        fontSize: 32,
        textAlign: "center",
    }
})