export default [
    {id: 1, nome: 'Last of Us 2', preco: 149.99},
    {id: 2, nome: 'Caderno', preco: 19.99},
    {id: 3, nome: 'PlayStation 5', preco: 2599.99},
    {id: 4, nome: 'Macbook', preco: 9879.99},
    {id: 5, nome: 'Caneta', preco: 4.99},
]